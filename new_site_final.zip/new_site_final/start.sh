#!/bin/sh
# Start Nginx
nginx

# Start Gunicorn
cd /app/backend
gunicorn --bind 0.0.0.0:5000 app:app &

# Keep container running
tail -f /dev/null